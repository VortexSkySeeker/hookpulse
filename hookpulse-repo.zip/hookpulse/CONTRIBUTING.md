# Contributing to HookPulse

Thank you for your interest in contributing to **HookPulse**!

## Local Development Setup

1. Clone the repository and create a virtual environment:
   ```bash
   python -m venv .venv
   source .venv/bin/activate
   ```
2. Install the package in editable mode:
   ```bash
   pip install -e .
   ```
3. Run the TUI in demo mode:
   ```bash
   python -m hookpulse.cli --demo
   ```
4. Run the test suite:
   ```bash
   python -m unittest discover -s tests -v
   ```

## Pull Request Checklist

- Ensure all unit tests pass (`python -m unittest discover -s tests`).
- Keep code clean, strictly typed, and free of unnecessary comments.
- Update `README.md` and `README.ru.md` if adding new CLI flags or keybindings.
