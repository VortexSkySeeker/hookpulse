---
name: Bug report
about: Report a bug or unexpected behavior in HookPulse
title: "[BUG] "
labels: bug
---

## Describe the bug
A clear and concise description of what the bug is.

## To Reproduce
1. Run `python hookpulse.py ...`
2. Send webhook `...`
3. Press key `...`

## Environment
- OS (e.g., Windows 11, macOS, Ubuntu):
- Python version:
- Terminal emulator:
