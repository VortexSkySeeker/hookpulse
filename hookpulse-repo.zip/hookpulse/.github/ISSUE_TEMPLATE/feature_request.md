---
name: Feature request
about: Suggest an idea or provider integration for HookPulse
title: "[FEAT] "
labels: enhancement
---

## Problem Statement
Describe the developer workflow or webhook debugging pain point.

## Proposed Solution
Describe how HookPulse should handle this.
