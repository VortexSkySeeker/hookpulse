import asyncio
from typing import Awaitable, Callable, Optional
from aiohttp import web
from .models import CapturedRequest
from .replay import replay_request


class WebhookCaptureServer:
    def __init__(
        self,
        host: str,
        port: int,
        on_request: Callable[[CapturedRequest], Awaitable[None]],
        forward_target: Optional[str] = None,
    ) -> None:
        self.host = host
        self.port = port
        self.on_request = on_request
        self.forward_target = forward_target
        self._runner: Optional[web.AppRunner] = None
        self._site: Optional[web.TCPSite] = None

    async def _handle_all(self, request: web.Request) -> web.Response:
        raw_bytes = await request.read()
        raw_text = raw_bytes.decode("utf-8", errors="replace")
        captured = CapturedRequest(
            method=request.method,
            path=request.path,
            headers=dict(request.headers),
            query_params=dict(request.query),
            raw_body=raw_text,
            client_ip=request.remote or "127.0.0.1",
        )
        if self.forward_target:
            asyncio.create_task(self._forward_and_notify(captured))
        else:
            await self.on_request(captured)
        return web.json_response(
            {
                "ok": True,
                "captured_id": captured.id,
                "source": captured.source_badge,
            },
            status=200,
        )

    async def _forward_and_notify(self, captured: CapturedRequest) -> None:
        if self.forward_target:
            await replay_request(captured, self.forward_target)
        await self.on_request(captured)

    async def start(self) -> None:
        app = web.Application(client_max_size=10 * 1024 * 1024)
        app.router.add_route("*", "/{tail:.*}", self._handle_all)
        self._runner = web.AppRunner(app, access_log=None)
        await self._runner.setup()
        self._site = web.TCPSite(self._runner, self.host, self.port)
        await self._site.start()

    async def stop(self) -> None:
        if self._runner:
            await self._runner.cleanup()
