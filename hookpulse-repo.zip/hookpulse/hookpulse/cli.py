import argparse
import sys
from .app import HookPulseApp
from .schema_gen import infer_pydantic_schema


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="hookpulse",
        description="HookPulse — Interactive TUI Webhook & API Request Debugger with instant Replay and Pydantic v2 schema generation.",
    )
    parser.add_argument("-p", "--port", type=int, default=9000, help="Local port to listen for incoming webhooks (default: 9000)")
    parser.add_argument("--host", type=str, default="0.0.0.0", help="Host address to bind (default: 0.0.0.0)")
    parser.add_argument("-t", "--target", type=str, default="http://localhost:8000", help="Target local server URL for Replay (default: http://localhost:8000)")
    parser.add_argument("--demo", action="store_true", help="Preload realistic Stripe, GitHub, and Telegram webhooks on startup")
    parser.add_argument("--schema-from-file", type=str, default=None, help="Generate Pydantic v2 schema directly from a JSON file and print to stdout")
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    if args.schema_from_file:
        with open(args.schema_from_file, "r", encoding="utf-8") as f:
            raw = f.read()
        print(infer_pydantic_schema(raw))
        return 0

    app = HookPulseApp(
        host=args.host,
        port=args.port,
        target_url=args.target,
        preload_demo=args.demo,
    )
    app.run()
    return 0


if __name__ == "__main__":
    sys.exit(main())
