import json
import keyword
import re
from typing import Any, Dict, List, Tuple


def _to_pascal_case(name: str) -> str:
    spaced = re.sub(r"([a-z0-9])([A-Z])", r"\1 \2", name)
    cleaned = re.sub(r"[^a-zA-Z0-9]+", " ", spaced).strip()
    if not cleaned:
        return "GeneratedModel"
    pascal = "".join(word.capitalize() for word in cleaned.split())
    if pascal[0].isdigit():
        pascal = f"Model{pascal}"
    return pascal


def _sanitize_field_name(key: str) -> Tuple[str, bool]:
    cleaned = re.sub(r"[^a-zA-Z0-9_]", "_", key)
    if not cleaned or cleaned[0].isdigit():
        cleaned = f"field_{cleaned}"
    if keyword.iskeyword(cleaned) or cleaned in {"model_config", "model_fields"}:
        return f"{cleaned}_", True
    return cleaned, cleaned != key


def infer_pydantic_schema(payload: Any, root_name: str = "WebhookPayload") -> str:
    if isinstance(payload, str):
        try:
            payload = json.loads(payload)
        except Exception:
            return "from pydantic import BaseModel\n\n\nclass RawPayload(BaseModel):\n    raw_body: str\n"

    models: List[str] = []
    visited_names: Dict[str, int] = {}

    def unique_model_name(base: str) -> str:
        pascal = _to_pascal_case(base)
        count = visited_names.get(pascal, 0)
        visited_names[pascal] = count + 1
        return pascal if count == 0 else f"{pascal}{count + 1}"

    def resolve_type(value: Any, field_hint: str) -> str:
        if value is None:
            return "Optional[Any]"
        if isinstance(value, bool):
            return "bool"
        if isinstance(value, int):
            return "int"
        if isinstance(value, float):
            return "float"
        if isinstance(value, str):
            return "str"
        if isinstance(value, list):
            if not value:
                return "List[Any]"
            first_non_null = next((item for item in value if item is not None), value[0])
            inner_type = resolve_type(first_non_null, f"{field_hint}Item")
            return f"List[{inner_type}]"
        if isinstance(value, dict):
            nested_name = unique_model_name(field_hint)
            build_model(value, nested_name)
            return nested_name
        return "Any"

    def build_model(obj: Dict[str, Any], model_name: str) -> None:
        lines = [f"class {model_name}(BaseModel):"]
        if not obj:
            lines.append("    pass")
            models.append("\n".join(lines))
            return

        for raw_key, val in obj.items():
            safe_name, needs_alias = _sanitize_field_name(str(raw_key))
            type_annotation = resolve_type(val, str(raw_key))
            if val is None:
                if needs_alias:
                    lines.append(f'    {safe_name}: {type_annotation} = Field(default=None, alias="{raw_key}")')
                else:
                    lines.append(f"    {safe_name}: {type_annotation} = None")
            else:
                if needs_alias:
                    lines.append(f'    {safe_name}: {type_annotation} = Field(alias="{raw_key}")')
                else:
                    lines.append(f"    {safe_name}: {type_annotation}")
        models.append("\n".join(lines))

    if isinstance(payload, dict):
        top_name = unique_model_name(root_name)
        build_model(payload, top_name)
    elif isinstance(payload, list):
        top_name = unique_model_name(root_name)
        sample = payload[0] if payload and isinstance(payload[0], dict) else {"items": payload}
        if isinstance(sample, dict):
            build_model(sample, top_name)
    else:
        return "from pydantic import BaseModel\n\n\nclass ScalarPayload(BaseModel):\n    value: str\n"

    header = "from typing import Any, List, Optional\nfrom pydantic import BaseModel, Field\n\n\n"
    return header + "\n\n\n".join(models) + "\n"
