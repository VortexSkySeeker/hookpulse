import time
import httpx
from .models import CapturedRequest, ReplayResult


async def replay_request(req: CapturedRequest, target_base_url: str, timeout: float = 10.0) -> ReplayResult:
    url = f"{target_base_url.rstrip('/')}{req.path}"
    excluded_headers = {"host", "content-length", "connection", "accept-encoding"}
    headers = {k: v for k, v in req.headers.items() if k.lower() not in excluded_headers}
    start = time.perf_counter()
    try:
        async with httpx.AsyncClient(timeout=timeout, follow_redirects=True) as client:
            response = await client.request(
                method=req.method,
                url=url,
                params=req.query_params,
                headers=headers,
                content=req.raw_body.encode("utf-8") if req.raw_body else b"",
            )
        elapsed_ms = round((time.perf_counter() - start) * 1000, 1)
        result = ReplayResult(
            status_code=response.status_code,
            elapsed_ms=elapsed_ms,
            response_body=response.text[:4000],
        )
    except Exception as exc:
        elapsed_ms = round((time.perf_counter() - start) * 1000, 1)
        result = ReplayResult(
            status_code=0,
            elapsed_ms=elapsed_ms,
            response_body="",
            error=str(exc),
        )
    req.last_replay = result
    return result


def build_demo_requests() -> list[CapturedRequest]:
    return [
        CapturedRequest(
            method="POST",
            path="/webhooks/stripe",
            headers={
                "Content-Type": "application/json",
                "Stripe-Signature": "t=1729412400,v1=6a8f9b2c4d1e",
                "User-Agent": "Stripe/1.0 (+https://stripe.com/docs/webhooks)",
            },
            query_params={"env": "staging"},
            raw_body='{"id":"evt_3Q9xLm2eZvKYlo2C","object":"event","api_version":"2024-06-20","created":1729412400,"type":"payment_intent.succeeded","data":{"object":{"id":"pi_3Q9xLm2eZvKYlo2C","amount":4900,"currency":"usd","customer":"cus_R1x9KpL2mN","status":"succeeded","metadata":{"plan":"pro_annual","user_id":8421}}}}',
            client_ip="54.187.205.235",
        ),
        CapturedRequest(
            method="POST",
            path="/webhooks/github",
            headers={
                "Content-Type": "application/json",
                "X-GitHub-Event": "push",
                "X-GitHub-Delivery": "9a7d8c20-8e4f-11ef-9b12-0242ac120002",
                "User-Agent": "GitHub-Hookshot/a1b2c3d",
            },
            query_params={},
            raw_body='{"ref":"refs/heads/main","repository":{"id":91827364,"name":"hookpulse","full_name":"dev/hookpulse","stargazers_count":1420,"private":false},"pusher":{"name":"alexdev","email":"alex@example.com"},"head_commit":{"id":"8f4e2a1c9b","message":"feat: add instant Pydantic v2 schema generator","timestamp":"2026-10-20T08:30:00Z"}}',
            client_ip="140.82.115.68",
        ),
        CapturedRequest(
            method="POST",
            path="/webhooks/telegram",
            headers={
                "Content-Type": "application/json",
                "X-Telegram-Bot-Api-Secret-Token": "tg_live_98f2a1c4b",
            },
            query_params={},
            raw_body='{"update_id":73918241,"message":{"message_id":412,"from":{"id":4918273,"is_bot":false,"first_name":"Nikita","username":"nikita_py"},"chat":{"id":4918273,"type":"private"},"date":1729412490,"text":"/deploy production"}}',
            client_ip="149.154.167.220",
        ),
    ]
