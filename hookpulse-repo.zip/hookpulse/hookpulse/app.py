import json
from typing import List, Optional
import pyperclip
from rich.panel import Panel
from rich.syntax import Syntax
from rich.table import Table
from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical
from textual.widgets import DataTable, Footer, Header, Input, Static, TabbedContent, TabPane
from .models import CapturedRequest
from .replay import build_demo_requests, replay_request
from .schema_gen import infer_pydantic_schema
from .server import WebhookCaptureServer


class HookPulseApp(App):
    CSS = """
    Screen {
        background: $surface-darken-1;
    }
    #top-bar {
        height: 3;
        background: $panel;
        border-bottom: solid $primary;
        padding: 0 2;
        content-align: left middle;
        color: $accent;
        text-style: bold;
    }
    #main-split {
        height: 1fr;
    }
    #left-pane {
        width: 44%;
        border-right: solid $primary;
    }
    #right-pane {
        width: 56%;
        padding: 0 1;
    }
    #filter-input {
        dock: top;
        margin: 1 1 0 1;
    }
    DataTable {
        height: 1fr;
    }
    .detail-box {
        padding: 1 1;
        height: 1fr;
        overflow-y: auto;
    }
    """

    BINDINGS = [
        Binding("r", "replay_selected", "Replay Request"),
        Binding("p", "copy_pydantic", "Copy Pydantic"),
        Binding("c", "copy_curl", "Copy cURL"),
        Binding("d", "load_demo", "Demo Webhooks"),
        Binding("x", "clear_requests", "Clear All"),
        Binding("s", "export_json", "Save JSON"),
        Binding("q", "quit", "Quit"),
    ]

    def __init__(
        self,
        host: str = "0.0.0.0",
        port: int = 9000,
        target_url: str = "http://localhost:8000",
        preload_demo: bool = False,
    ) -> None:
        super().__init__()
        self.host = host
        self.port = port
        self.target_url = target_url
        self.preload_demo = preload_demo
        self.requests: List[CapturedRequest] = []
        self.filtered_requests: List[CapturedRequest] = []
        self.selected_request: Optional[CapturedRequest] = None
        self.server: Optional[WebhookCaptureServer] = None

    def compose(self) -> ComposeResult:
        yield Header(show_clock=True)
        yield Static(
            f"⚡ HookPulse Listening on http://{self.host}:{self.port}   ➔   Replay Target: {self.target_url}",
            id="top-bar",
        )
        with Horizontal(id="main-split"):
            with Vertical(id="left-pane"):
                yield Input(placeholder="Filter by path, source (Stripe/GitHub), or method...", id="filter-input")
                yield DataTable(id="request-table", cursor_type="row")
            with Vertical(id="right-pane"):
                with TabbedContent(initial="tab-body"):
                    with TabPane("JSON / Body", id="tab-body"):
                        yield Static("Select or send a webhook to inspect payload.", id="view-body", classes="detail-box")
                    with TabPane("Pydantic v2 Schema", id="tab-schema"):
                        yield Static("Select a JSON webhook to generate Pydantic v2 models.", id="view-schema", classes="detail-box")
                    with TabPane("Headers & Replay", id="tab-headers"):
                        yield Static("Headers and replay status will appear here.", id="view-headers", classes="detail-box")
                    with TabPane("cURL Command", id="tab-curl"):
                        yield Static("cURL command will appear here.", id="view-curl", classes="detail-box")
        yield Footer()

    async def on_mount(self) -> None:
        table = self.query_one("#request-table", DataTable)
        table.add_columns("Time", "Method", "Source", "Path", "Replay")
        self.server = WebhookCaptureServer(
            host=self.host,
            port=self.port,
            on_request=self.handle_incoming_request,
        )
        await self.server.start()
        if self.preload_demo:
            for item in build_demo_requests():
                self.requests.append(item)
            self._refresh_table()

    async def on_unmount(self) -> None:
        if self.server:
            await self.server.stop()

    async def handle_incoming_request(self, req: CapturedRequest) -> None:
        self.requests.insert(0, req)
        self._refresh_table()
        self.notify(f"Captured {req.method} {req.path} ({req.source_badge})", title="Incoming Webhook")

    def _refresh_table(self) -> None:
        query = self.query_one("#filter-input", Input).value.strip().lower()
        table = self.query_one("#request-table", DataTable)
        table.clear()
        self.filtered_requests = [
            r
            for r in self.requests
            if not query
            or query in r.path.lower()
            or query in r.method.lower()
            or query in r.source_badge.lower()
            or query in r.raw_body.lower()
        ]
        for req in self.filtered_requests:
            if req.last_replay:
                if req.last_replay.error:
                    replay_label = "ERR"
                else:
                    replay_label = f"{req.last_replay.status_code} ({req.last_replay.elapsed_ms}ms)"
            else:
                replay_label = "—"
            table.add_row(req.timestamp, req.method, req.source_badge, req.path, replay_label, key=req.id)

        if self.filtered_requests and self.selected_request is None:
            self.selected_request = self.filtered_requests[0]
            self._update_detail_views(self.selected_request)
        elif self.selected_request:
            self._update_detail_views(self.selected_request)

    def on_input_changed(self, event: Input.Changed) -> None:
        if event.input.id == "filter-input":
            self._refresh_table()

    def on_data_table_row_highlighted(self, event: DataTable.RowHighlighted) -> None:
        if event.row_key and event.row_key.value:
            req_id = str(event.row_key.value)
            for req in self.filtered_requests:
                if req.id == req_id:
                    self.selected_request = req
                    self._update_detail_views(req)
                    break

    def _update_detail_views(self, req: CapturedRequest) -> None:
        body_widget = self.query_one("#view-body", Static)
        schema_widget = self.query_one("#view-schema", Static)
        headers_widget = self.query_one("#view-headers", Static)
        curl_widget = self.query_one("#view-curl", Static)

        formatted = req.formatted_body
        lexer = "json" if req.parsed_json is not None else "text"
        body_widget.update(Syntax(formatted or "<Empty Body>", lexer, theme="monokai", word_wrap=True))

        schema_code = infer_pydantic_schema(req.parsed_json if req.parsed_json is not None else req.raw_body)
        schema_widget.update(Syntax(schema_code, "python", theme="monokai", word_wrap=True))

        hdr_table = Table(show_header=True, header_style="bold cyan", expand=True)
        hdr_table.add_column("Header", style="bold cyan", width=28)
        hdr_table.add_column("Value", style="white")
        for k, v in req.headers.items():
            hdr_table.add_row(k, v)
        if req.last_replay:
            rep = req.last_replay
            status_line = f"Error: {rep.error}" if rep.error else f"HTTP {rep.status_code} in {rep.elapsed_ms} ms"
            hdr_table.add_row("Last Replay Status", status_line)
        headers_widget.update(Panel(hdr_table, title=f"{req.method} {req.path} ({req.size_bytes} bytes)"))

        curl_cmd = req.to_curl(self.target_url)
        curl_widget.update(Syntax(curl_cmd, "bash", theme="monokai", word_wrap=True))

    async def action_replay_selected(self) -> None:
        if not self.selected_request:
            self.notify("Select a request first.", severity="warning")
            return
        req = self.selected_request
        self.notify(f"Replaying {req.method} {req.path} -> {self.target_url} ...")
        result = await replay_request(req, self.target_url)
        self._refresh_table()
        if result.error:
            self.notify(f"Replay failed: {result.error}", severity="error")
        else:
            self.notify(f"Replay HTTP {result.status_code} ({result.elapsed_ms} ms)", title="Replay Complete")

    def action_copy_pydantic(self) -> None:
        if not self.selected_request:
            return
        req = self.selected_request
        code = infer_pydantic_schema(req.parsed_json if req.parsed_json is not None else req.raw_body)
        try:
            pyperclip.copy(code)
            self.notify("Pydantic v2 schema copied to clipboard!", title="Copied")
        except Exception:
            self.notify("Clipboard unavailable in headless environment; view in Pydantic tab.", severity="warning")

    def action_copy_curl(self) -> None:
        if not self.selected_request:
            return
        cmd = self.selected_request.to_curl(self.target_url)
        try:
            pyperclip.copy(cmd)
            self.notify("cURL command copied to clipboard!", title="Copied")
        except Exception:
            self.notify("Clipboard unavailable in headless environment; view in cURL tab.", severity="warning")

    def action_load_demo(self) -> None:
        for item in build_demo_requests():
            self.requests.insert(0, item)
        self._refresh_table()
        self.notify("Loaded 3 sample webhooks (Stripe, GitHub, Telegram)", title="Demo Mode")

    def action_clear_requests(self) -> None:
        self.requests.clear()
        self.filtered_requests.clear()
        self.selected_request = None
        self._refresh_table()
        self.notify("Cleared all captured webhooks.")

    def action_export_json(self) -> None:
        data = [r.to_dict() for r in self.requests]
        with open("hookpulse_history.json", "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        self.notify("Saved captured requests to hookpulse_history.json", title="Exported")
