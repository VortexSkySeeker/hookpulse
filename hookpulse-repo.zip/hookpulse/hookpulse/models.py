from dataclasses import dataclass, field
from datetime import datetime
import json
import shlex
from typing import Any, Dict, Optional
import uuid


@dataclass
class ReplayResult:
    status_code: int
    elapsed_ms: float
    response_body: str
    timestamp: str = field(default_factory=lambda: datetime.now().strftime("%H:%M:%S"))
    error: Optional[str] = None


@dataclass
class CapturedRequest:
    method: str
    path: str
    headers: Dict[str, str]
    query_params: Dict[str, str]
    raw_body: str
    client_ip: str = "127.0.0.1"
    id: str = field(default_factory=lambda: uuid.uuid4().hex[:8])
    timestamp: str = field(default_factory=lambda: datetime.now().strftime("%H:%M:%S.%f")[:-3])
    last_replay: Optional[ReplayResult] = None

    @property
    def parsed_json(self) -> Optional[Any]:
        if not self.raw_body:
            return None
        try:
            return json.loads(self.raw_body)
        except Exception:
            return None

    @property
    def formatted_body(self) -> str:
        parsed = self.parsed_json
        if parsed is not None:
            return json.dumps(parsed, indent=2, ensure_ascii=False)
        return self.raw_body or ""

    @property
    def size_bytes(self) -> int:
        return len(self.raw_body.encode("utf-8")) if self.raw_body else 0

    @property
    def source_badge(self) -> str:
        lower_headers = {k.lower(): v for k, v in self.headers.items()}
        if "stripe-signature" in lower_headers:
            return "Stripe"
        if "x-github-event" in lower_headers:
            return f"GitHub:{lower_headers['x-github-event']}"
        if "x-telegram-bot-api-secret-token" in lower_headers or "telegram" in self.path.lower():
            return "Telegram"
        if "svix-id" in lower_headers:
            return "Svix"
        return "HTTP"

    def to_curl(self, base_url: str = "http://localhost:8000") -> str:
        target = f"{base_url.rstrip('/')}{self.path}"
        if self.query_params:
            qs = "&".join(f"{k}={v}" for k, v in self.query_params.items())
            target = f"{target}?{qs}"
        parts = ["curl", "-X", self.method, shlex.quote(target)]
        excluded = {"host", "content-length", "connection", "accept-encoding"}
        for k, v in self.headers.items():
            if k.lower() not in excluded:
                parts.extend(["-H", shlex.quote(f"{k}: {v}")])
        if self.raw_body:
            parts.extend(["-d", shlex.quote(self.raw_body)])
        return " \\\n  ".join(parts)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "timestamp": self.timestamp,
            "method": self.method,
            "path": self.path,
            "headers": self.headers,
            "query_params": self.query_params,
            "raw_body": self.raw_body,
            "client_ip": self.client_ip,
        }
