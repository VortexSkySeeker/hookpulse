import unittest
from hookpulse.models import CapturedRequest
from hookpulse.schema_gen import infer_pydantic_schema
from hookpulse.replay import build_demo_requests


class TestHookPulse(unittest.TestCase):
    def test_demo_requests_and_badges(self) -> None:
        demos = build_demo_requests()
        self.assertEqual(len(demos), 3)
        self.assertEqual(demos[0].source_badge, "Stripe")
        self.assertTrue(demos[1].source_badge.startswith("GitHub:"))
        self.assertEqual(demos[2].source_badge, "Telegram")

    def test_pydantic_schema_generation(self) -> None:
        sample = {
            "id": "evt_123",
            "amount": 4900,
            "paid": True,
            "customer": {"email": "dev@example.com", "tier": "pro"},
            "tags": ["webhook", "stripe"],
        }
        code = infer_pydantic_schema(sample, root_name="StripeEvent")
        self.assertIn("class StripeEvent(BaseModel):", code)
        self.assertIn("class Customer(BaseModel):", code)
        self.assertIn("amount: int", code)
        self.assertIn("paid: bool", code)
        self.assertIn("tags: List[str]", code)

    def test_curl_generation(self) -> None:
        req = CapturedRequest(
            method="POST",
            path="/webhooks/stripe",
            headers={"Content-Type": "application/json", "X-Custom": "abc"},
            query_params={"retry": "1"},
            raw_body='{"ok":true}',
        )
        curl_str = req.to_curl("http://localhost:8000")
        self.assertIn("http://localhost:8000/webhooks/stripe?retry=1", curl_str)
        self.assertIn("X-Custom: abc", curl_str)


if __name__ == "__main__":
    unittest.main()
